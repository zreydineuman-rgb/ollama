const http=require('http');
const server=http.createServer((req,res)=>{
    if(req.url == '/'&& req.method === 'GET'){
        res.end(JSON.stringify({"message":"accediendo al server"}));
    }
    res.end('Hola Mundo');
});
const port=5000;
const host='localhost';
server.listen(port,host,()=>{
    console.log(`El servidor esta corriendo en http://${host}:${port}`);
}); 