const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const UserAuthSchema = new Schema({
    email: {
        type: String,
        required: true,
        unique: true,
        trim: true
    },
    password: {
        type: String,
        required: true
    },
    role: {
        type: String,
        enum: ['admin', 'user'], 
    }
}, {
    timestamps: true
});

const UserAuth = mongoose.model('UserAuth', UserAuthSchema);

module.exports = UserAuth;
