const e = require('express')
const mongoose = require('mongoose')
const schema = mongoose.Schema

const userSchema = new schema({
    nombre: String,
    apellido: String,
    email: String,
    telefono: String
})
 
const User=mongoose.model('User', userSchema)
module.exports=User