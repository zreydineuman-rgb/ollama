const AuthService = require('../services/authService');
const bcrypt = require('bcrypt');

const authService = new AuthService();

exports.register = async (req, res) => {
  try {
    const newUser = await authService.register(req.body);
    res.status(201).json({ mensaje: "Usuario registrado exitosamente" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await authService.filterByEmail(email);

    if (!user) {
      return res.status(404).json({ success: false, mensaje: "Usuario no encontrado" });
    }

    const passwordMatch = bcrypt.compareSync(password, user.password);
    if (!passwordMatch) {
      return res.status(401).json({ success: false, mensaje: "Contraseña incorrecta" });
    }

    const token = authService.generateToken(user);
    res.status(200).json({
      success: true,
      mensaje: "Inicio de sesión exitoso",
      userEmail: user.email,
      token: token.accessToken 
    });

  } catch (error) {
    console.error("Error en login:", error);
    res.status(500).json({ success: false, mensaje: "Error en el servidor" });
  }
};