const UserService = require('../services/UserService');
const userService = new UserService()


exports.getUsers =async (req, res) => {
    const users=await userService.getAll();
    res.status(200).json(users)
        
}

exports.getUser=async(req,res)=>{
    const id=req.params.id
    const user=await userService.filterById(id)
    if(!user){
        return res.status(400).json({"message":"Usuario no encontrado"})
    }
    res.status(200).json(user)
}
exports.createUser = async (req, res) => {
    try {
        let data = req.body;
        await userService.create(data);
        res.status(201).send('Usuario creado');
    } catch (error) {
        res.status(500).send({ error: error.message });
    }

}



exports.updateUser=(req,res)=>{
    let data=req.body;
    const{ nombre, apellido, email, telefono}=data
    console.log(nombre, apellido, email, telefono);
    console.log(req.params.id);
    console.log(nombre, apellido, email, telefono);
    res.send('Usuario actualizado');
}
exports.deleteUser=(req,res)=>{
    console.log(req.params.id);
    res.send('Usuario eliminado');
}
