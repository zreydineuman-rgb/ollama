const axios = require('axios');



module.exports = (io) => {

 let messages = [{ username: "Sistema", message: "Bienvenido al chat con Ollama 🤖" }];



 io.on('connection', (socket) => {

  console.log('Nuevo cliente conectado');

  io.emit('all-messages', messages);



  socket.on('writing', (username) => {

   socket.broadcast.emit('user-writing', username);

  });



  socket.on('new-message', async (data) => {

   // Guardar mensaje del usuario

   messages.push(data);

   io.emit('all-messages', messages);



   try {

    // Llamar a Ollama para obtener la respuesta

    const respuesta = await obtenerRespuestaOllama(data.message);



    const botMsg = {

     username: "Ollama 🤖",

     message: respuesta,

    };



    // Enviar respuesta del bot al chat

    messages.push(botMsg);

    io.emit('all-messages', messages);

   } catch (error) {

    console.error('Error al comunicarse con Ollama:', error.message);

   }

  });

 });

};



// =========================

// 🔌 Función para Ollama

// =========================

async function obtenerRespuestaOllama(prompt) {

 const response = await axios.post('http://localhost:11434/api/generate', {

  model: 'llama3',

  prompt: prompt,

  stream: false,

 });



 return response.data.response.trim();

}

