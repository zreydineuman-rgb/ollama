module.exports = {
    db: {
        host: "localhost",
        user: "", // Si no usas usuario, déjalo vacío
        password: "", // Si no usas contraseña, déjalo vacío
        database: "mydb3",
        port: 27017
    }
}   