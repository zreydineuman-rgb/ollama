const User = require(`../models/userModel`);

class UserService {
    async create(data) {
        const user = new User(data);
        return await user.save();
    }

    async filterById(id) {
        return await User.findById(id);
    }

    async getAll() {
        return await User.find();
    }

    async update(id, data) {
        return await User.findByIdAndUpdate({ _id: id }, data, { new: true });
    }

    async delete(id) {
        return await User.deleteOne({ _id: id });
    }
}

module.exports = UserService;