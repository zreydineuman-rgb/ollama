const express = require('express');
const router = express.Router();
const getController = require('../controllers/userController');

router.get('/', getController.getUsers);
router.get('/:id', getController.getUser);
router.post('/', getController.createUser);
router.put('/:id', getController.updateUser);
router.delete('/:id', getController.deleteUser);

module.exports = router;