const express = require('express');
const router = express.Router();
const {verifyToken}=require('../middlewares/verifyToken')

router.get('/', (req, res) => {
    res.status(200).send('Dashboard Home')

});
module.exports = router;
