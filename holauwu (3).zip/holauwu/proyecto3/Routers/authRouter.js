const express = require('express');
const router = express.Router();
const AuthController = require('../controllers/authController');
const { verifyToken, verifyRole } = require('../middlewares/authMiddleware');

// Vistas de registro y login
router.get('/register', (req, res) => res.render('auth/register'));
router.get('/login', (req, res) => res.render('auth/login'));

// Controladores de autenticación
router.post('/register', AuthController.register);
router.post('/login', AuthController.login);

// Perfil protegido con token
router.get('/profile', verifyToken, (req, res) => {
  res.json({ 
    mensaje: `Hola ${req.user.email}, tu rol es ${req.user.role}` 
  });
});

// Solo administradores
router.get('/admin', verifyToken, verifyRole('admin'), (req, res) => {
  res.json({ 
    mensaje: `Bienvenido administrador ${req.user.email}` 
  });
});
router.get('/bienvenido', (req, res) => {
  const email = req.query.email || 'Usuario';
  res.render('auth/bienvenido', {
    title: 'Bienvenido',
    userEmail: email
  });
});


module.exports = router;
