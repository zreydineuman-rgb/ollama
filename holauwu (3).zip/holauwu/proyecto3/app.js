const express=require('express');
const app=express();

const morgan=require('morgan');

const path=require('path');
const connection=require('./database/connection')
const authRouter=require('./Routers/authRouter')
const dashboardRouter=require('./Routers/dashboardRouter')
const socketio=require('socket.io')


app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.get('/',(req,res)=>{

res.render('index')
})    

app.get('/',(req,res)=>{
    console.log('servidor creado por express');

})


app.use(morgan('dev'));
app.use(express.json());

app.use('/auth', authRouter);
app.use('/dashboard', dashboardRouter);
app.use(express.static(__dirname + '/public'));

const server=require('http').createServer(app);
const io=socketio(server)
require('./socket')(io);    

server.listen(3000, () => {
    console.log('servidor escuchando en el puerto 3000');
})