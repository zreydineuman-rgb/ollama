const mongoose = require('mongoose');
const {db}=require('../config');

const connection=mongoose.connect(`mongodb://${db.host}:${db.port}/${db.database}`)
.then(()=>{
    console.log('conectado a la base de datos')
}).catch(()=>{
    console.log('error al conectar a la base de datos')
});

module.exports=connection
  