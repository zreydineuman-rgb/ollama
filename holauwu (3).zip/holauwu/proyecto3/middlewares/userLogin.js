const userLogin = (req, res, next) => {
    let isLogin = true; // Simulamos que el usuario está logueado
    if (!isLogin) {
        return res.status(401).send('message Usuario no logueado');
        
    }
    next();
}

module.exports = userLogin;