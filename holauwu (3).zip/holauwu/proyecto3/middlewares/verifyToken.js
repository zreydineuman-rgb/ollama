const jwt=require('jsonwebtoken');
exports.verifyToken=(req,res,next)=>{
    const authorization=req.headers.authorization
    console.log(authorization);
    if(!authorization){
        res.status(401).json({"message":"Token no enviado"})
    }
    try {
        const token=authorization.split(' ')[1]

    } catch (error) {
        return res.status(400).json({error:error.message})
    }
}   

