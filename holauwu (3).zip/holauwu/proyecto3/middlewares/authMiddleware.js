const jwt = require('jsonwebtoken');
const AuthService = require('../services/authService'); // ✅ Importar el servicio
const authService = new AuthService();

const secretKey = process.env.JWT_SECRET || 'secret-key';

// 🔹 Middleware para verificar el token JWT
exports.verifyToken = async (req, res, next) => {
  const header = req.headers['authorization'];

  // Verificar si el encabezado existe
  if (!header) {
    return res.status(403).json({ mensaje: 'Token requerido' });
  }

  // Extraer el token del encabezado (formato "Bearer <token>")
  const token = header.split(' ')[1];
  if (!token) {
    return res.status(403).json({ mensaje: 'Token no proporcionado' });
  }

  try {
    //  Usar el método verifyToken del servicio
    const result = authService.verifyToken(token);
    
    if (!result.valid) {
      if (result.expired) {
        return res.status(401).json({ 
          mensaje: 'El token ha expirado. Por favor, inicia sesión nuevamente.',
          expired: true 
        });
      }
      return res.status(401).json({ mensaje: result.message });
    }

    req.user = result.decoded; // Guardar datos del usuario en la request
    next(); // Continuar con la siguiente función
    
  } catch (error) {
    return res.status(401).json({ mensaje: 'Error al verificar el token.' });
  }
};

// 🔹 Middleware para verificar rol del usuario
exports.verifyRole = (role) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ mensaje: 'Usuario no autenticado.' });
    }

    if (req.user.role !== role) {
      return res.status(403).json({ mensaje: 'No tienes permiso para acceder a esta ruta.' });
    }

    next();
  };
};